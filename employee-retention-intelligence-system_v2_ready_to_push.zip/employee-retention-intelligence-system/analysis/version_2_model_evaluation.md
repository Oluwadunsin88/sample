# Version 2 Model Evaluation

## Simulation and target
- Synthetic employee population: 2,000
- Simulated Version 2 exits: 130
- Simulated attrition rate: 6.50%
- Monthly workforce history after exits: 24,182 observations
- Eligible six-month outcome observations: 14,226
- Positive labelled observations: 652
- Negative labelled observations: 13,574
- Censored observations: 9,956

The target is 1 when a recorded Version 2 exit occurs after the observation date and within the next six months. It is 0 when no exit occurs within that six-month window and the full window ends by 31 December 2025. Observations without a complete six-month follow-up are censored and excluded from modelling.

## Chronological evaluation
- Training: 31 January–30 June 2024 (1,753 observations; 52 positive labels).
- Embargo: July–December 2024.
- Test: 31 January–30 June 2025 (7,537 observations; 264 positive labels).

## Logistic Regression holdout results
| Metric | Result |
|---|---:|
| Accuracy | 0.6247 |
| Precision | 0.0382 |
| Recall | 0.4015 |
| F1-score | 0.0697 |
| ROC-AUC | 0.5263 |
| PR-AUC | 0.0423 |

Confusion matrix (actual rows: stayed, attrition; predicted columns: stayed, attrition):

```text
[[4602 2671]
 [ 158  106]]
```

The test set contains 264 positive observations out of 7537 (3.50%). The model identifies 106 of these at the default 0.50 threshold, with 2671 false-positive observations. Precision is only 3.82%, so the current model should not be used to make employee-level decisions.

## Model comparison
| Model               |   ROC_AUC |   PR_AUC |
|:--------------------|----------:|---------:|
| Logistic Regression |    0.5263 |   0.0423 |
| Random Forest       |    0.5199 |   0.0372 |
| Gradient Boosting   |    0.4737 |   0.0355 |
| Extra Trees         |    0.5058 |   0.0353 |

## Interpretation and limitations
- These are synthetic data and simulated resignations, not observed employee outcomes.
- The resignation mechanism is constructed from the same experience indicators supplied to the model. This creates a designed relationship, not evidence of causality in real organisations.
- The six-month labels overlap across adjacent monthly observations; records are not independent employee-level cases.
- The chronological test set is later than the training set, but the training set is small and contains relatively few positive observations.
- The PR-AUC (0.0423) is only modestly above test prevalence (0.0350). Discrimination remains weak.
- The model's default threshold is not optimised for HR action. Threshold selection would require a separate validation period and explicit cost assumptions.
- Use the analysis to demonstrate data preparation, temporal validation, classification evaluation and responsible interpretation—not to rank actual employees or automate employment decisions.

## Exit reason counts
| Exit_Reason             |   Count |
|:------------------------|--------:|
| Workload and overtime   |      47 |
| Work-life balance       |      27 |
| Management relationship |      20 |
| Low engagement          |      18 |
| Job dissatisfaction     |      18 |

