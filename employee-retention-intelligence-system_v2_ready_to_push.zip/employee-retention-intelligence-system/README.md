# Employee Retention Intelligence & Attrition Early Warning System

A synthetic-data portfolio project exploring workforce retention patterns and a six-month attrition classification workflow.

## Project question
Can employee experience indicators help identify observations associated with resignation within the following six months?

## Project scope
- Generate a synthetic workforce of 2,000 employees.
- Create employee-level and monthly workforce datasets.
- Simulate monthly employee experience indicators.
- Simulate resignation events from a time-varying monthly risk mechanism.
- Construct six-month outcome labels while retaining right-censored observations.
- Evaluate a Logistic Regression model using a chronological holdout and six-month embargo.
- Document model limitations and responsible-use considerations.

## Version 2 simulation snapshot
| Item | Result |
|---|---:|
| Synthetic employees | 2,000 |
| Simulated resignations | 130 |
| Simulated attrition rate | 6.50% |
| Monthly observations after exits | 24,182 |
| Eligible six-month observations | 14,226 |
| Positive labelled observations | 652 |
| Negative labelled observations | 13,574 |
| Censored observations | 9,956 |

## Version 2 model evaluation
Chronological training period: January–June 2024. July–December 2024 is an embargo period. Test period: January–June 2025.

| Metric | Result |
|---|---:|
| Accuracy | 0.6247 |
| Precision | 0.0382 |
| Recall | 0.4015 |
| F1-score | 0.0697 |
| ROC-AUC | 0.5263 |
| PR-AUC | 0.0423 |

The model's PR-AUC is 0.0423, compared with a test positive prevalence of 0.0350. This is a weak result. At the default 0.50 threshold, precision is 3.82%; the model produces many false positives. It is not suitable for operational employee-level risk decisions.

## Key simulation assumptions
The synthetic resignation hazard is calculated from satisfaction, work-life balance, engagement, manager relationship, workload and overtime indicators. The hazard coefficients and baseline hazard are design assumptions, not estimates from real organisational data.

## Repository structure
- `data/raw/` — original Version 1 synthetic source datasets.
- `data/processed/` — Version 2 exits, monthly history, labelled modelling data and holdout predictions.
- `documentation/` — data dictionary.
- `notebooks/` — original data generation notebook and expanded modelling notebook.
- `analysis/` — Version 2 evaluation, model comparison and feature diagnostics.
- `visualisations/` — Version 2 charts.

## Limitations and responsible use
- All data and exits are synthetic.
- The model learns from a simulated process whose risk mechanism is based on the same experience indicators used as predictors.
- Monthly observations from the same employee are repeated and six-month outcome windows overlap.
- The holdout performance is weak and the default threshold creates many false positives.
- The model must not be used to rank, discipline, dismiss or make employment decisions about real people.
- Any real-world application would require representative, consented data; validation across time and groups; calibration; fairness assessment; and meaningful human oversight.

## Tools
Python, Pandas, NumPy, scikit-learn, Matplotlib, Google Colab and Git/GitHub.

## Reproducibility
Run `01_Data_Generation.ipynb` to generate the original synthetic datasets. Run `02_Data_Preparation_and_Modelling.ipynb` for the Version 1 experiments and Version 2 simulation, target construction, modelling and export.
